#include<iostream>
#include<cstring>
using namespace std;

char Arr[] = {'A' , 'B' , 'C' , 'D', 'E' , 'F' , 'G', 'H' , 'I' ,'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
void CharToNumber(char c){
	int n;
	for(int i = 0 ; i < 26 ; i ++){
		if(c == Arr[i]){
			n = i;
			cout<<"C :" <<n;
			break;
		}
	}
}

void NumberToChar(int n){
	char c;
	for(int i = 0 ; i < 26 ; i ++){
		if(n == i){
			c = Arr[i];
			cout<<"N :"<<c<<endl;
			break;
		}
	}
}

int main(){
	char s;
	cout<<"Enter a string : ";
	cin>>s;
	CharToNumber(s);
	NumberToChar(1);
	return 0;
}
