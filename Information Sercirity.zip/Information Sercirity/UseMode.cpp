//C = E(P , K) = (P + K ) MOD 26
//P = E(P , K) = (P - K ) MOD 26
	
#include<iostream>
#include<cstring>
using namespace std;

char Arr[] = {'A' , 'B' , 'C' , 'D', 'E' , 'F' , 'G', 'H' , 'I' ,'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', ' '};
char arr[] = {'a' , 'b' , 'c' , 'd', 'e' , 'f' , 'g', 'h' , 'i' ,'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' , ' '};
int CharToNumber(char &c){
	int n;
	for(int i = 0 ; i < 26 ; i ++){
		if(c == Arr[i] || c == arr[i]){
			n = i;
			break;
		}
	}
	return n;
}

char NumberToChar(int &n){
	char c;
	for(int i = 0 ; i < 26 ; i ++){
		if(n == i){
			c = Arr[i];
			break;
		}
	}
	return c;
}

char UpToLow(char &c){
	for(int i = 0 ; i < 26 ; i++){
		if(c == Arr[i]){
			c = arr[i];
			break;
		}
	}
	return c;
}

char LowToUp(char &c){
	for(int i = 0 ; i < 26 ; i++){
		if(c == arr[i]){
			c = Arr[i];
			break;
		}
	}
	return c;
}

int main(){
	string s1 , s3;
	char c;
	int n1[s1.size()] , n2;
	cout<<"Enter a string : ";
	getline(cin , s1);
	
	
	for(int i = 0 ; i < s1.size() ; i++){
		n1[i] = CharToNumber(s1[i]);
		s3[i] = UpToLow(s1[i]);
	}

	for(int i = 0 ; i < s1.size() ; i++){
	//	cout<<n1[i];
	//	cout<<s3[i];
	}
	int tmp;
	for(int i = 0 ; i < s1.size() ; i++){
		tmp = ((n1[i] + 10) % 26 );
		c = NumberToChar(tmp);
	}
	cout<<"C : "<<c<<endl;
	
	cout<<"\nEnter a nunber : ";
	cin>>n2;
	for(int i = 0 ; i < 26 ; i++){
		c = NumberToChar(n2);
	}
	
	cout<<"N1 : "<<c<<endl;
	
	cin.ignore();
	string s2 ;
	cout<<"Enter a string : ";
	getline(cin , s2);
	
	for(int i = 0 ; i < s2.size() ; i ++){
		s2[i] = s2[i] + 5;
	}
	cout<<"String after Encription : "<<s2<<endl;
	
//	for(int i = 0 ; i < s2.size() ; i ++){
//		s2[i] = s2[i] - 5;
//	}
//	cout<<"String after Description : "<<s2<<endl;
//	
	cout<<"UnLock"<<endl;
	for(int i = 0 ; i < 26 ; i++){
		s3 = s2 ;
		for(int j = 0 ; j < s3.size() ; j++){
			s3[j] = s3[j] - i;
		}
		cout<<"String after Description : "<<s3<<endl;
	}
	
	return 0;
}

