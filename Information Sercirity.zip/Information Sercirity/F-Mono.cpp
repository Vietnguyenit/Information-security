// tinh tan suat xuat hien cua cac ky tu xuat hien trong chuoi cho truoc
#include<iostream>
#include<cstring>
using namespace std;


int main(){
	string s , s1 ;
	bool check = false;
	cout<<"Nhap vao 1 chuoi : ";
	cin>>s;
	int n = s.size();
	
	for(int i = 0 ; i < s.size() ; i++){
		for(int j = i+1 ; j < s.size() ){
			if(s[i] == s[j]){
				check = false;
				
			}
			else{
				check = true;
			}
		}
		
		
		if(check){
			n--;
		}else{
			
		}		
	}
	
	
	
	
	for(int i = 0 ; i < n ; i++){
		cout<<s[i];
	}
	
	
	return 0;
}
