#include<iostream>


using namespace std;

char Arr[] = {'A' , 'B' , 'C' , 'D', 'E' , 'F' , 'G', 'H' , 'I' ,'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

//Convert char to number
int charToNumber(char c){
	for(int i = 0 ; i < 26 ; i ++){
		if(c == Arr[i]){
			return i;
		}
	}
}

//Convert number to char
char numberToChar(int n){
	
	for (int i = 0; i < 26; i++)
		if(n == i)
			return Arr[i];
}

int main(){
	char s1;
	string s ;
	int k;
	
	cout<<"Nhap chuoi : ";
	getline(cin , s);
	
	cout<<"Nhap k = ";
	cin>>k;
	
	int b[s.size()];
	
	//MA HOA
	//Chuyen tu chuoi sang so
	for(int i = 0; i < s.size(); i++){
		int a[1];
		a[0] = charToNumber(s[i]);
		//cout<<"a0 "<<a[0]<<endl;
		b[i] = a[0];
	}
	//Size cua b
	int size = sizeof(b)/sizeof(int);
	//cout<<"size"<<size;
	
	//Ma hoa
	for (int i = 0; i < size; i++){
		b[i] = (b[i] + k) % 26;
	}
	
	cout<<"Chuoi sau khi ma hoa la: ";
	for (int i = 0; i < s.size(); i++){
		cout<<b[i];
	}
	
	//GIAI MA
	for (int i = 0; i < size; i++){
		b[i] = (b[i] - k) % 26;
		
		if (b[i] < 0){
			b[i] = b[i] + 26;
		}
		
	}
	
	char c[size];
	
	//chuyen tu so sang chuoi
	for (int i = 0; i < size; i++){
		char d[1];
		d[0] = numberToChar(b[i]);
		c[i] = d[0];
	}
	
	//Giai ma
	
	cout<<"\n Chuoi sau khi giai ma la: ";

	for (int i = 0; i < size; i++){
		cout<<c[i];
	}
	return 0;
	
}

