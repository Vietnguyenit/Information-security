#include<iostream>
#include<cstring>
#include<cstdlib>
using namespace std;

char Arr[] = {'A' , 'B' , 'C' , 'D', 'E' , 'F' , 'G', 'H' , 'I' ,'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' , ' ' };
char arr[] = {'a' , 'b' , 'c' , 'd', 'e' , 'f' , 'g', 'h' , 'i' ,'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' , ' '};
int CharToNumber(char c){
	int n;
	for(int i = 0 ; i < 27 ; i ++){
		if(c == Arr[i] || c == arr[i]){
			n = i;
			break;
		}
	}
	return n;
}

char NumberToChar(int n){
	char c;
	for(int i = 0 ; i < 27 ; i ++){
		if(n == i){
			c = Arr[i];
			break;
		}
	}
	return c;
}

char UpToLow(char c){
	for(int i = 0 ; i < 27 ; i++){
		if(c == Arr[i]){
			c = arr[i];
			break;
		}
	}
	return c;
}

char LowToUp(char c){
	for(int i = 0 ; i < 27 ; i++){
		if(c == arr[i]){
			c = Arr[i];
			break;
		}
	}
	return c;
}

int main(){
	string s1,s2,s3,s4,s6,s7,s11,s12,s13,s15 ;
	char c;
	char c1[s1.size()] , c1s[s1.size()];
	int n1[s1.size()] , n  , tmp[s1.size()]  , tmpn[s1.size()];
	int choose = 0;
	char ans ;
	do{
		do{
			system("CLS");
			cout<<"0. Enter a string "<<endl;
			cout<<"1. Up to Low "<<endl;
			cout<<"2. Low to Up "<<endl;
			cout<<"3. Char to Number "<<endl;
			cout<<"4. Number to Char "<<endl;
			cout<<"5. Encription then Description a string (Unlock) "<<endl;
			cout<<"6. Encription then Description a string "<<endl;
			cout<<"7. Encription then Description a string to Number and else "<<endl;
			cout<<"8. Exit "<<endl;
			cout<<"Choose (0 - 8) : ";
			cin>>choose;
			switch(choose) {
				case 0:
					cout<<"Enter a string : ";
					cin.ignore();
					getline(cin , s1);
					break;
				case 1 :
					s11 = s1;
					for(int i = 0 ; i < s11.size() ; i++){
						s2[i] = UpToLow(s11[i]);
					}
					cout<<"After Up To Low "<<endl;
					for(int i = 0 ; i < s11.size() ; i++){
						cout<<s2[i];
					}		
					break;
				case 2 :
					s12 = s1;
					for(int i = 0 ; i < s12.size() ; i++){
						s3[i] = LowToUp(s12[i]);
					}
					cout<<"After Up To Low "<<endl;
					for(int i = 0 ; i < s12.size() ; i++){
						cout<<s3[i];
					}
				
					break;
				case 3 :
					s13 = s1;
					for(int i = 0 ; i < s13.size() ; i++){
						n1[i] = CharToNumber(s13[i]);
					}
					cout<<"After Char To Number ";
					for(int i = 0 ; i < s13.size() ; i++){
						cout<<n1[i]<<endl;
					}
					
					break;
				case 4 :
					cout<<"Enter a Number : ";
					cin>>n;
					c = NumberToChar(n);
					cout<<"Number = "<<n<<" -> Char = "<<c<<endl;
					system("PAUSE");
					break;
				case 5 :
					s15 = s1;
					cout<<"Encription"<<endl;
					for(int i = 0 ; i < s15.size() ; i++){
						s15[i] = s15[i] + 10;
					}
					system("PAUSE");
					cout<<"Descripting....."<<endl;
					for(int i = 0 ; i < 27 ; i++){
						s4 = s1 ;
						for(int j = 0 ; j < s4.size() ; j++){
							s4[j] = s4[j] - i;
						}
					cout<<"String after Description : "<<s4<<endl;
					}
					system("PAUSE");
					break;
				case 6 :
					s6 = s1;
					cout<<s6;
					cout<<"Encription"<<endl;
					for(int i = 0 ; i < s6.size() ; i++){
						tmpn[0] = CharToNumber(s6[i]);
						tmp[0] = ((tmpn[0] + 3 ) % 27);
						c1[i] = NumberToChar(tmp[0]);
					}
					cout<<"String before Description : ";
					for(int i = 0 ; i < s1.size() ; i++){
						cout<<c1[i];
					}
					
					cout<<endl;
					system("PAUSE");
					cout<<"Description"<<endl;
					for(int i = 0 ; i < s6.size() ; i++){
						tmpn[0] = CharToNumber(c1[i]);
						tmp[0] = ((tmpn[0] - 3 ) % 27);
						if(tmp[0] < 0){
							tmp[0] = tmp[0] + 27 ;
						}
						c1s[i] = NumberToChar(tmp[0]);
					}
					cout<<"String after Description : ";
					for(int i = 0 ; i < s6.size() ; i++){
						cout<<c1s[i];
					}
					cout<<endl;
					system("PAUSE");
					break;
				case 7 :
					s7 = s1 ;
					cout<<s7;
					cout<<"Encription"<<endl;
					for(int i = 0 ; i < s7.size() ; i++){
						tmpn[0] = CharToNumber(s7[i]);
						tmp[i] = ((tmpn[0] + 3 ) % 27);
					}
					cout<<"String before Description : ";
					for(int i = 0 ; i < s7.size() ; i++){
						cout<<tmp[i];
					}
					cout<<endl;
					system("PAUSE");
					cout<<"Descripting..."<<endl;
					for(int i = 0 ; i < s7.size() ; i++){
						tmp[0] = ((tmp[i] - 3 ) % 27);
						if(tmp[0] < 0){
							tmp[0] = tmp[0] + 27 ;
						}
						c1s[i] = NumberToChar(tmp[0]);
					}
					cout<<"String after Description : ";
					for(int i = 0 ; i < s7.size() ; i++){
						cout<<c1s[i];
					}
					cout<<endl;
					system("PAUSE");
					break;
				case 8 :
					exit(1);
					break;
				default :
					break;
			}
		
		}while(choose > 8 || choose < 0 );
		cout<<"\nDo you wanna continue ? ( y / n ) : ";
		cin>>ans;
	}while(ans == 'y' || ans == 'Y');
	return 0;
}
