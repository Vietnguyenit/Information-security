#include<iostream>
#include <iomanip>
#include<cstring>
using namespace std;

char Arr[] = {'A' , 'B' , 'C' , 'D', 'E' , 'F' , 'G', 'H' , 'I' ,'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

//Convert char to number
int charToNumber(char c){
	for(int i = 0 ; i < 26 ; i ++){
		if(c == Arr[i]){
			return i;
		}
	}
}

//Convert number to char
char numberToChar(int n){
	
	for (int i = 0; i < 26; i++)
		if(n == i)
			return Arr[i];
}

//Create String To Int[]
int* stringToInt(string str){
	int a[str.size()];
	
	for (int i = 0; i < str.size(); i++){
		a[i] = charToNumber(str[i]);
	}
	return a;
}

//Create Int[] To string
string intToString(int b[]){
	string str = "";
	for (int i = 0; i < sizeof(b); i++){
		str += numberToChar(b[i]);
		
	}
	return str;
}


int main(){
	char s1;
	string s ;
	int k;
	
	cout<<"Nhap chuoi : ";
	getline(cin , s);
	cout<<"Nhap k = ";
	cin>>k;
	
	//Ma hoa
	int* b;
	
	//Convert string to int[]
	b = stringToInt(s);
	int size = sizeof(b)/sizeof(int);
	for (int i = 0; i < size; i++){
		cout<<b[i]<<endl;
	}
	
	int c[size];
	
	for(int i = 0; i < size; i++){
		c[i] = (b[i] + k) % 26;
	}
	cout<<"Chuoi da duoc ma hoa la: ";
	
	int size1 = sizeof(c)/sizeof(int);
	for (int i = 0; i < size1; i++){
		cout<<c[i]<<endl;
	}
	 
	//Giai ma
	string d;
	
	for (int i = 0; i < size1; i++){
		c[i] =  (c[i] - k) % 26;
		if (c[i] < 0){
			c[i] = c[i] + ((26 - k) % 26);
		}
	}
	
	//Convert int[] to string
	d = intToString(c);
	cout<<" Chuoi sau khi giai ma la: "<<d;
	
	return 0;
	
}

