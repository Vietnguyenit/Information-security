#include<iostream>

using namespace std;

char  kyTu[] ={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
	
int kyTuSo(char c){
	int a=-1;
		for(int i =0; i < 26; i++){
			if(c == kyTu[i]){
				a= i;
				break;
			}
		}
		return a;
	}

int main(){
	
	string str ="abcd";
	fflush(stdin);getline(cin, str);
	cout <<"Chuoi ban dau : " <<str<< endl;
	//encryption
	for(int i =0; i < str.size(); i++){
		if(str[i] != ' ')
		str[i]=kyTu[(kyTuSo(str[i])+3)%26];	
	}
	cout <<"chuoi da encryption : " << str<<endl;
	//decryption
	for(int i =0; i < str.size(); i++){
		if(str[i] != ' ')
		str[i]=kyTu[(kyTuSo(str[i])+23)%26];	
	}
	cout <<"chuoi da decryption : " << str<<endl;
}

