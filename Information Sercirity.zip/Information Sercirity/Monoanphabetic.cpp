#include<iostream>
using namespace std;
char arr[] = {'a' , 'b' , 'c' , 'd', 'e' , 'f' , 'g', 'h' , 'i' ,'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

int Position(char c){
	for(int i = 0 ; i < 26 ; i++){
		if(c == arr[i]){
			return i;
		}
	}
}

char NumberToChar(int n){
	for(int i = 0 ; i < 26 ; i++){
		if(n == i){
			return arr[i];
		}
	}
}

int main(){
	string s , s1 , s2 , s3;
	int index = 0;
	bool check = false;
	char k;
	int n[s.size()]  , n1[s.size()] ;
	cout<<"Enter a string : ";
	cin>>s;
	cout<<"Enter K(select random A - Z (26) ) "<<endl;
	for(int i = 0 ; i < 26 ; i++){
		do{
			cout<<"K["<<i<<"] = ";
			cin>>k;
			for(int j = 0 ; j < index ; j++){
				if( k == s1[j]){
					check = true;
					cout<<"It's existed"<<endl;
					break;
				}
				else{
					check = false;
				}
			}
		}while(check);
		s1[i] = k;
		index++;
	}
	
	//s1 = "qpowieurytalksjdhfgmnbvcxz";
	cout<<"K : ";
	for(int i = 0 ; i < 26 ; i++){
		cout<<s1[i]<<" ";
	}
	cout<<"\nPosition"<<endl;
	
	for(int i = 0 ; i < s.size() ; i++ ){
		n[i] = Position(s[i]);
		cout<<n[i] <<" ";
	}
	
	cout<<"\nEncription string : ";
	for(int i = 0 ; i < s.size() ; i++){
		cout<<s1[n[i]];
	}
	
	cout<<"\nDescription string : ";
	cout<<endl;
	for(int i = 0 ; i < 26 ; i++){
		for(int j = 0 ; j < s.size() ; j++){
			if(s1[n[j]] == s1[i]){
				cout<<arr[i];
			}
		}
	}

	
	
	
	
	return 0;
}
