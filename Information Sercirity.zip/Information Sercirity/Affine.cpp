#include<iostream>
#include<cstring>
#include<cstdlib>
using namespace std;

char Arr[] = {'A' , 'B' , 'C' , 'D', 'E' , 'F' , 'G', 'H' , 'I' ,'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
char arr[] = {'a' , 'b' , 'c' , 'd', 'e' , 'f' , 'g', 'h' , 'i' ,'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
int CharToNumber(char c){
	int n;
	for(int i = 0 ; i < 26 ; i ++){
		if(c == Arr[i] || c == arr[i]){
			n = i;
			break;
		}
	}
	return n;
}

char NumberToChar(int n){
	char c;
	for(int i = 0 ; i < 26 ; i ++){
		if(n == i){
			c = Arr[i];
			break;
		}
	}
	return c;
}

int A_1(int a){
	for(int i = 1 ; i < 26 ; i++){
		if( (i * a) % 26 == 1 ){
			return i;
			break;	
		} 	
	}
}
int A[] = {1 , 3 , 5 , 7 , 9 , 11 , 15 , 17 , 19 , 21 , 23 , 25 };

int main(){		
	string s , s1 , s2 , s4;
	int a , b ; // a thuoc A[] ; 0<b<26
	int c[s.size()] ;
	
	cout<<"Moi nhap chuoi : ";
	cin>>s;
	bool kt = false;
	while(!kt){
		cout<<"Nhap a : ";
		cin>>a;
		for(int i = 0 ; i < 12 ; i++){
			if(a == A[i]){
				kt = true;
			}
		}
	}
	do{
		cout<<"Nhap b : ";
		cin>>b;
	}while(b > 26 || b < 0);
	
	
	
	// Ma hoa
	for(int i = 0 ; i < s.size() ; i++){
		c[0] = CharToNumber(s[i]);
		c[1] = (a * c[0] + b) % 26 ; 
		s1[i] = NumberToChar(c[1]);
	}
	cout<<"Chuoi da ma hoa : ";
	for(int i = 0 ; i < s.size() ; i++){
		cout<<s1[i];
	}
//	for(int i = 0 ; i < s.size() ; i++){
//		c[0] = CharToNumber(s1[i]);
//		c[1] = (A_1(a) *(c[0] - b + 26)) % 26 ; 
//		s2[i] = NumberToChar(c[1]);
//		//cout<<s2[i];
//	}
//	
//
//	
//	cout<<"\nChuoi giai ma : ";
//	for(int i = 0 ; i < s.size() ; i++){
//		cout<<s2[i];
//	}
	cout<<endl;
	//be khoa
	int count = 0;
	int stt = 0;
	for(int i = 0 ; i < 12 ; i++){
		for(int j = 0 ; j < 26 ; j++){
			cout<<stt++<<" a = "<<A[i]<<" B = "<<j<<" => Chuoi =  ";
			for(int k = 0 ; k < s.size() ; k++){
				c[0] = CharToNumber(s1[k]);
				c[1] = (A_1(A[i]) *(c[0] - j + 26)) % 26 ; 
				s4[k] = NumberToChar(c[1]);
				cout<<s4[k];
			}
			count++;
			cout<<endl;
		}
	}
	
	cout<<count;
	return 0;
}



