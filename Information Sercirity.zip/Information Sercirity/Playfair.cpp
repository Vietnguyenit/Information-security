#include<iostream>
using namespace std;

char M[5][5];
string key = "KHUONGDUY";

void TaoMaTran()
{
	int dem = 0;
	for(int i = 0;i < key.size();i++)
	{
		char j = 'J';
		if(key[i] == j)
		{
			key[i]='I';
		}
		 int a = dem / 5;
		 int b = dem % 5;
		 bool check  = true;
		 for(int j = 0;j<5;j++)
		 	for(int z = 0; z < 5 ; z++)
		 	{
		 		if(M[j][z] == key[i])
		 		{
		 			check = false;
		 		}
		 	}
		if(check)
		{
			M[a][b] = key[i];
			dem++;
		}
		
	}
	for(char i = 'A';i <= 'Z'; i++)
	{
		if( i == 'J')
		{
			continue;
		}
		int a = dem / 5;
		int b = dem % 5;
		bool check = true;
		for(int j = 0;j<5;j++)
		 	for(int z = 0; z < 5 ; z++)
				if(M[j][z] == i)
				{
					check = false;
				}
		if(check)
		{
			M[a][b] = i;
			dem++;
		}
	}
	
}
void mahoa(char& s1, char& s2)
{
	int x1,y1,x2,y2;
	for(int i = 0;i<5;i++)
		for(int j = 0; j < 5 ; j++)
		{
			if(s1 == M[i][j])
			{
				x1 = i;
				y1 = j;
			}
			if(s2 == M[i][j])
			{
				x2 = i;
				y2 = j;
			}
		}
		//cout<<endl<<x1<<","<<y1<<"-----"<<x2<<","<<y2;
	if(x1 != x2 && y1 != y2)
	{
		int tg = y1;
		y1 = y2;
		y2 = tg;
	} else if(x1 == x2)
	{
		y1 = y1 +1;
		y2 = y2 + 1;
		if(y1 > 4)
		{
			y1 = 0;
		}
		if(y2 > 4)
		{
			y2 = 0;
		}
	} else if(y2 == y1)
	{
		x1 = x1 + 1;
		x2 = x2 + 1;
		if(x1 > 4)
		{
			x1 = 0;
		}
		if(x2 > 4)
		{
			x2 = 0;
		}
	}
	s1 = M[x1][y1];
	s2 = M[x2][y2];
	//cout<<endl<<x1<<","<<y1<<"-----"<<x2<<","<<y2;
}
char* substring(char* s,int pos)    {
    
    char* t = &s[pos];
    s[pos-1] = '\0';
    return t;
}
int main()
{
	string s;
	cout<<"Moi ban nhap KEY";
	cin>>key;
	cout<<"\nNhap chuoi";
	cin>>s;
	TaoMaTran();
	bool check = true;
	while(check)
	for(int i = 0; i < s.size();i++)
	{
		if(i % 2 == 0)
		{
			string ss = "";
			char a = substring(s,i+1);
			ss = ss + a;
			ss = ss + "X";
			
			
		}
	}
	
	if(s.size() % 2 == 1)
	{
		s = s + "X";
	}
	
	
	return 0;
}
